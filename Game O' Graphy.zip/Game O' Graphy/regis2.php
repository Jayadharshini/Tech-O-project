<?php
$name = $_POST["name"];
$email = $_POST["email"];
$subject = $_POST["subject"];
$message = $_POST["message"];
$conn=mysqli_connect("localhost","root");
mysqli_select_db($conn,"gameography");
if ($mysqli->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}
$select = "insert into hockeycoach(name,email,subject,message)values('".$name."','".$email."','".$subject."','".$message."')";
//echo $select."2";
$sql=mysqli_query($conn,$select);
echo mysqli_error($conn);
echo "inserted successfully";
mysqli_close($conn);
header('location:hockeycoach.html')
?>